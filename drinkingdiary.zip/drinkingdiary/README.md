# jsdd
Javascript-based version of the drinkingdiary site.  

drinkingdiary html app enables users to calculate how many units they drink, and record this on a daily basis to see if their drinking is within healthy limits. It provides weekly unit averages by week, month, and year periods so that users can if desired bring down the ammount they consume.

To get started, download app bundle, unzip folder to your desktop and open the contained web page in a browser. Click on any day to enter the number of alcoholic units consumed - the diary will track your totals and averages from there on in.


